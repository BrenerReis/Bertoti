



public class Pedido {
    private String numeroDaMesa;
    private String horaDoPedido;
    private String tipoDeGrao;
    private String tipoDeSalada;
    private String acompanhamento;

    public Pedido(String numeroDaMesa, String horaDoPedido, String tipoDeGrao, String tipoDeSalada, String acompanhamento) {
        this.numeroDaMesa = numeroDaMesa;
        this.horaDoPedido = horaDoPedido;
        this.tipoDeGrao = tipoDeGrao;
        this.tipoDeSalada = tipoDeSalada;
        this.acompanhamento = acompanhamento;
    }

    
    
     
    
    
    public String getNumeroDaMesa() {
        return numeroDaMesa;
    }

    public void setNumeroDaMesa(String numeroDaMesa) {
        this.numeroDaMesa = numeroDaMesa;
    }

    public String getHoraDoPedido() {
        return horaDoPedido;
    }

    public void setHoraDoPedido(String horaDoPedido) {
        this.horaDoPedido = horaDoPedido;
    }

    public String getTipoDeGrao() {
        return tipoDeGrao;
    }

    public void setTipoDeGrao(String tipoDeGrao) {
        this.tipoDeGrao = tipoDeGrao;
    }

    public String getTipoDeSalada() {
        return tipoDeSalada;
    }

    public void setTipoDeSalada(String tipoDeSalada) {
        this.tipoDeSalada = tipoDeSalada;
    }

    public String getacompanhamento() {
        return acompanhamento;
    }

    public void setacompanhamento(String acompanhamento) {
        this.acompanhamento = acompanhamento;
    }
    
    
    public boolean  comparar(Pedido pedido){
        if(numeroDaMesa.equals(pedido.numeroDaMesa)&&
            horaDoPedido.equals(pedido.horaDoPedido)&&
            tipoDeGrao.equals(pedido.tipoDeGrao)&&
            tipoDeSalada.equals(pedido.tipoDeSalada)&&
            acompanhamento.equals(pedido.acompanhamento)){
        return true;
        }else{
            return false;
        }
    }       
     
}
