import org.junit.jupiter.api.Test;


import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class Teste {

	@Test
	public void test() {
		
		Restaurante restaurante = new Restaurante();
		
		
		assertEquals(restaurante.getClintes().size(), 0);
		
		restaurante.cadastrarCliente(new Cliente("Brener", new Pedido("10", "12:20", "Arroz", "Tomate", "PeitoDeFrango")));
		restaurante.cadastrarCliente(new Cliente("Joao", new Pedido("05", "12:30", "ArrozIntegral", "Pepino", "Lasanha")));
		
		assertEquals(restaurante.getClintes().size(), 2);
		
		
		Cliente clienteEncontrado = restaurante.buscarClientePorNome("Joao");
		
		assertEquals(clienteEncontrado.getPedi().getTipoDeGrao(), "ArrozIntegral"); 
		
	
		List<Cliente> clientesEncontrados = restaurante.buscarClientePorPedido(new Pedido("10", "12:20", "Arroz", "Tomate", "PeitoDeFrango"));
		
		assertEquals(clientesEncontrados.get(0).getPedi().getTipoDeGrao(), "Arroz");
	}

}
