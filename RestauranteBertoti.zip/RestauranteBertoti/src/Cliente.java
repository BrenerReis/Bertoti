



public class Cliente {
    private String nome;
    private Pedido pedi;

    public Cliente(String nome, Pedido pedi) {
        this.nome = nome;
        this.pedi = pedi;
    }

    
    
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Pedido getPedi() {
        return pedi;
    }

    public void setPedi(Pedido pedi) {
        this.pedi = pedi;
    }
    
    
}
